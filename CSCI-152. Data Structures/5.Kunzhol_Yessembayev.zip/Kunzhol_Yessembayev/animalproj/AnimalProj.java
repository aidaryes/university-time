/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animalproj;

public interface AnimalProj {
    
    public String animalKind();
    
    public int getAge();
    
    public int ageOneYear();
           
    public boolean canEat(String food);
    
    /*
    Returns can animal entertain humans
    @return the place where animal can entertain humans
    */
    public boolean canEntertain(String place);
    
    /*
    Return can animal feed itself
    @return true or false when animal can hunting or etc
    */
    public boolean canFeedItself();
    
}
