/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animalproj;

/*
Here we use a constructor
*/
public class Cow extends AnimalImpl {

    public Cow(int age, int maxage) {
        super(age, maxage);
    }

    @Override
    public String animalKind() {
        return "Cow";
    }

    @Override
    public boolean canEat(String food) {
        if(food.equals("Grass")){
            return true;
        }
        return false;
    }

    @Override
    public boolean canEntertain(String place) {
        if(place.equals("Cowshed")){
            return true;
        }
        return false;
    }

    @Override
    public boolean canFeedItself() {
        return false;
    }
    
}
