/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animalproj;

public class AnimalImpl implements AnimalProj {
    
    private int age;
    private int maxage;
    private boolean isAlive;
    
    public AnimalImpl(int age, int maxage){
        this.age = age;
        this.maxage = maxage;
        
        if (age < maxage)
        {
            isAlive = true;
        }
        else
        {
            isAlive = false;
        }
    }
    
    @Override
    public int getAge() {
        return age;
    }

    public boolean getIsAlive(){
        return isAlive;
    }
    /**
     *
     * @return -1 if Animal is dead
     */
    @Override
    public int ageOneYear() {
        age++;
        
        if(age < maxage){
        return age;
        }
        else{
        isAlive=false;
        return -1;
        } 
    }
    
        
    @Override
    public String animalKind() {
        return "Override";
    }

    @Override
    public boolean canEat(String food) {
        return true;
    }

    @Override
    public boolean canEntertain(String place) {
        return true;
    }

    @Override
    public boolean canFeedItself() {
        return true;
    }
    
}
