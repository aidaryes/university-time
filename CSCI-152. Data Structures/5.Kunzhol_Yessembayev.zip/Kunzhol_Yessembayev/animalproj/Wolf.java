/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animalproj;

public class Wolf extends AnimalImpl {

/*
Here we use a constructor
*/
    public Wolf(int age, int maxage) {
        super(age, maxage);
    }

    @Override
    public String animalKind() {
        return "Wolf";
    }

    @Override
    public boolean canEat(String food) {
        if(food.equals("Meet")){
            return true;
        }
        return false;
    }

    @Override
    public boolean canEntertain(String place) {
        return false;
    }
    
    @Override
    public boolean canFeedItself() {
        return true;
    }
    
}
