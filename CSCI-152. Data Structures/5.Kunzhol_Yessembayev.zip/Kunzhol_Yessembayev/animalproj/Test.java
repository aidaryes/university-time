/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animalproj;

public class Test {
    
    public static void main(String[] args) {
        AnimalProj animal1 = new Tiger(16, 25);
        System.out.println(animal1.animalKind());
        System.out.println(animal1.canEat("Meet"));
        System.out.println(animal1.getAge());
        System.out.println(animal1.ageOneYear());
        System.out.println(animal1.canEntertain("Zoo"));
        System.out.println(animal1.canFeedItself());
        AnimalImpl animal1mod = (AnimalImpl) animal1;
        System.out.println(animal1mod.getIsAlive());
        
        AnimalProj animal2 = new Cow(24, 25);
        System.out.println(animal2.animalKind());
        System.out.println(animal2.canEat("Meet"));
        System.out.println(animal2.getAge());
        System.out.println(animal2.ageOneYear());
        System.out.println(animal2.canEntertain("Zoo"));
        System.out.println(animal2.canFeedItself());
        AnimalImpl animal2mod = (AnimalImpl) animal2;
        System.out.println(animal2mod.getIsAlive());
        
        AnimalProj animal3 = new Wolf(13, 25);
        System.out.println(animal3.animalKind());
        System.out.println(animal3.canEat("Meet"));
        System.out.println(animal3.getAge());
        System.out.println(animal3.ageOneYear());
        System.out.println(animal3.canEntertain("Zoo"));
        System.out.println(animal3.canFeedItself());
        AnimalImpl animal3mod = (AnimalImpl) animal3;
        System.out.println(animal3mod.getIsAlive());
        
    }
}
