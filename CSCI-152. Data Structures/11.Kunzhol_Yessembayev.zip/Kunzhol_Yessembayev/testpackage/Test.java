
package testpackage;
import csci152.adt.*;
import csci152.impl.*;

public class Test {
    public static void main(String[] args) throws Exception{
        Queue<Integer> tralala = new LinkedListQueue<Integer>();
        
//        tralala.dequeue();
//        System.out.println(tralala);
        
        for(int i=0; i<8; i++){
            tralala.enqueue(i);
        }
        System.out.println(tralala);
        System.out.println(tralala.getSize());
        
        for(int i=0; i<3; i++){
            tralala.dequeue();
        }
        System.out.println(tralala);
        System.out.println(tralala.getSize());

        for(int i=0; i<9; i++){
            tralala.enqueue(i);
            tralala.enqueue(i+1);
            tralala.dequeue();
            tralala.dequeue();
        }
        System.out.println(tralala);
        System.out.println(tralala.getSize());
        
        tralala.clear();
        System.out.println(tralala);
        System.out.println(tralala.getSize()); 
        
        for(int i=0; i<22; i++){
            tralala.enqueue(i);
        }
        System.out.println(tralala);
        System.out.println(tralala.getSize());        
        
        
    }
    
}
