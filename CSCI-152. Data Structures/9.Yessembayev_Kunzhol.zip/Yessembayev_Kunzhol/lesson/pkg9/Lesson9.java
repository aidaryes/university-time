
package lesson.pkg9;
import csci152.impl.*;


public class Lesson9 {

    public static void main(String[] args) {
       ArrayQueue<Integer> queue = new ArrayQueue<Integer>();
       ArrayStack<Integer> exp1 = new ArrayStack<Integer>();
  
		try
		{
			queue.dequeue();
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		for (int i = 0; i < 8; i++)
		{
			queue.enqueue(i);
		}
		System.out.println(queue);
		System.out.println("Size is: " + queue.getSize());
		
		try
		{
			queue.dequeue();
			queue.dequeue();
			queue.dequeue();
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		System.out.println(queue);
		System.out.println("Size is: " + queue.getSize());
		
		for (int i = 0; i < 9; i++)
		{
			queue.enqueue(i);
			queue.enqueue(i + 1);
			
			try
			{
				queue.dequeue();
				queue.dequeue();
			}
			catch (Exception e)
			{
				System.out.println(e.getMessage());
			}
			
			System.out.println(queue);
			System.out.println("Size is: " + queue.getSize());
			
		}
		
		queue.clear();
		System.out.println(queue);
		System.out.println("Size is: " + queue.getSize());
		
		
		for(int i = 0; i < 22; i++){
			 queue.enqueue(i);
		}
		System.out.println(queue);
		System.out.println("Size is: " + queue.getSize());

	    
		try
		{
		    exp1.pop();
		}
		catch(Exception e)
		{
		    System.out.println(e.getMessage());
		}
		
		for (int i = 0; i < 12; i++)
		{
		    exp1.push(i);
		}
		
		System.out.println(exp1);
		System.out.println("Size of stack " +  exp1.getSize());
		
		for (int i = 0; i < 3; i++)
		{
                    try{
                    exp1.pop();
                    }
                    catch(Exception e){
                        System.out.println(e.getMessage());
                    }
		}
		
		System.out.println(exp1);
		System.out.println("Size of stack " +  exp1.getSize());
		
		exp1.clear();
		System.out.println(exp1);
		System.out.println("Size of stack " +  exp1.getSize());
		
		for (int i = 0; i < 22; i++)
		{
		    exp1.push(i);
		}
		
		System.out.println(exp1);
		System.out.println("Size of stack " +  exp1.getSize());
		
}
}
