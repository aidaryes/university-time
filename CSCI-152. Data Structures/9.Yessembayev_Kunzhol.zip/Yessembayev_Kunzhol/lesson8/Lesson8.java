
package lesson8;
import csci152.adt.*;
import csci152.impl.*;


public class Lesson8 {

   
    public static void main(String[] args) throws Exception {
       
        Stack<Integer> tauka = new ArrayStack<Integer>();
        
        for (int i = 1; i < 3; i++)
        {
            tauka.push(i);
        }
        
        Queue<Integer> aidaruwka = new ArrayQueue<Integer>();
        
        for (int i = 1; i <= 3; i++)
        {
            aidaruwka.enqueue(i);
        }
        
        for (int i = 6; i >= 1; i--)
        {
            aidaruwka.enqueue(i);
        }
        
        /*
        First exercise, method evenCount
        */       
        //System.out.println(Test.evenCount(tauka));
        //System.out.println(tauka);
        
        /*
        Fourth exercise, method reverseStack
        */
        //System.out.println(tauka);
        //Test.reverseStack(tauka);
        //System.out.println(tauka);
        
        /*
        Sixth exercise, isPalindrome
        */
        System.out.println(Test.isPalindrome(aidaruwka));      
        System.out.println(aidaruwka);
        
        
        
        
        
        
    }
    
}
