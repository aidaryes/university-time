package lesson8;
import csci152.adt.*;
import csci152.impl.*;

public class Test {
   
    public static int evenCount(Stack<Integer> stk) throws Exception{
      Stack<Integer> temp = new ArrayStack();
      Stack<Integer> temp2 = new ArrayStack();
      int size = stk.getSize();
      for ( int i = 0; i < size; i++)
      {
          int popped = stk.pop();
          temp2.push(popped);
          
          if (popped % 2 == 0)
          {
              temp.push(popped);
          }
      }
      
      size = temp2.getSize();
      
      for (int i = 0; i < size; i++)
      {
          stk.push(temp2.pop());
      }
      
      return temp.getSize();
    }
    
    public static void reverseStack(Stack toRev) throws Exception{
        Queue aidar = new ArrayQueue();
        
        int size = toRev.getSize();
        
        for (int i = 0; i < size; i++)
        {
            aidar.enqueue(toRev.pop());
        }
        
        for(int i = 0; i < size; i++)
        {
            toRev.push(aidar.dequeue());
        }       
    }
    
    public static boolean isPalindrome(Queue<Integer> q) throws Exception {
        
        Queue<Integer> temp1 = new ArrayQueue();
        Stack<Integer> temp2 = new ArrayStack();
        
        Queue<Integer> tempuwka = new ArrayQueue();
        
        int size = q.getSize();
        
        if (size % 2 == 0)
        {
            for (int i = 0; i < size / 2; i++)
            {
                int last = q.dequeue();
                
                temp1.enqueue(last);
                tempuwka.enqueue(last);
            }
            
            for (int i = 0; i < size / 2; i++)
            {
                int last = q.dequeue();
                
                temp2.push(last);
                tempuwka.enqueue(last);
            }
            
            for (int i = 0; i < size; i++)
            {
            q.enqueue(tempuwka.dequeue());
            }
            
            for (int i = 0; i < size / 2; i++)
            {
                if (temp1.dequeue() != temp2.pop())
                {
                    return false;
                }
            }
            
            return true;
        }
        else
        {
            for (int i = 0; i < size / 2; i++)
            {
                int last = q.dequeue();
                
                temp1.enqueue(last);
                tempuwka.enqueue(last);
            }
            
            tempuwka.enqueue(q.dequeue());
            
            for (int i = 0; i < size / 2; i++)
            {
                int last = q.dequeue();
                
                temp2.push(last);
                tempuwka.enqueue(last);
            }
            
            for (int i = 0; i < size; i++)
            {
            q.enqueue(tempuwka.dequeue());
            }
            
            for (int i = 0; i < size / 2; i++)
            {
                if (temp1.dequeue() != temp2.pop())
                {
                    return false;
                }
            }
            
            return true;
        }
            
        
    }
}

