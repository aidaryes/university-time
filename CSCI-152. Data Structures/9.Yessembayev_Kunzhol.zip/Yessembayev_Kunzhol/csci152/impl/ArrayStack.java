package csci152.impl;
import csci152.adt.*;

/* Name of the class has to be "Main" only if the class is public. */
public class ArrayStack<T> implements Stack<T>
{
    private T[] values;
    private int size;
    
    public ArrayStack() {
        values = (T[])(new Object[10]);
        size = 0;
    }
    
    @Override
    public void push(T value)
    {
        values[size] = value;
        size++;
        
        if (size == values.length)
        {
		T[] temp = (T[])new Object[2 * size];

		for (int i = 0; i < size; i++)
		{
			temp[i] = values[i];
		}

		values = temp;
        }
    }
    
    @Override
    public T pop() throws Exception
    {
        if (size == 0)
        {
            throw new Exception("Size of Stack is 0");
        }
        
        T result = values[size - 1];
        values[size - 1] = null;
        size--;
        return result;
    }
    
    @Override
    public int getSize()
    {
        return size;
    }
    
    @Override
    public void clear()
    {
        values = (T[])new Object[10];
        size = 0;
    }
    
    @Override
    public String toString()
    {
       String toReturn = "bottom ";
       
       for (int i = 0; i < size; i++)
       {
           toReturn += values[i] + " ";
       }
       
       toReturn += "top";
       
       return toReturn;
    }
}
