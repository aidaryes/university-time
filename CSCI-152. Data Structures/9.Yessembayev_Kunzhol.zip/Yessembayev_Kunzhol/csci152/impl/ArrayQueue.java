package csci152.impl;
import csci152.adt.*;
        
public class ArrayQueue<T> implements Queue<T> {
	
	T[] values;
	int cap;
	int size, front, back;
	
	public ArrayQueue()
	{
		values = (T[])(new Object[5]);
		cap = 5;
		size = 0;
		front = 0;
		back = 0;
	}

        @Override
	public void enqueue(T value) {
		
		if (size < cap)
		{
			values[back] = value;
			back = (back + 1) % cap;
			size++;
		}
		else if (size == cap)
		{
			T[] temp = (T[])new Object[2 * cap];
			int tempInd = 0;
			
			for (int i = front; i < cap; i++)
			{
				temp[i - front] = values[i];
				tempInd = i - front + 1;
			}
			
			for (int i = 0; i < back; i++)
			{
				temp[tempInd + i] = values[i];
			}
			
			
			front = 0;
			back = cap;
			
			values = temp;
			cap *= 2;
			
			enqueue(value);
		}
		
	}

	public T dequeue() throws Exception {
		if (size == 0)
		{
			throw new Exception("Queue is empty");
		}
		
		T result = values[front];
                values[front] = null;
		front = (front + 1) % cap;
		size--;
		
		return result;
	}

	public int getSize() {
		return size;
	}

        @Override
	public void clear() {
		values = (T[])new Object[5];
		cap = 5;
		size = 0;
		front = 0;
		back = 0;
		
	}
	
        @Override
	public String toString()
	{
		String toReturn = "front--> ";
		
		if (front < back)
		{
			for (int i = front; i < back; i++)
			{
				toReturn += values[i] + " ";
			}
		}
		else
		{
			for (int i = front; i < cap; i++)
			{
				toReturn += values[i] + " ";
			}
			
			for (int i = 0; i < back; i++)
			{
				toReturn += values[i] + " ";
			}
		}
		
		toReturn += "<--back";
		
		return toReturn;
	}
}
