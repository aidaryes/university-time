package testpackage;
import csci152.adt.*;
import csci152.impl.*;


public class TestClass {
	
	public static void main(String[] args) throws Exception
	{
		Stack<Integer> mypony = new LinkedListStack<Integer>(); 
		
		for (int i = 0; i < 12; i++)
		{
			mypony.push(i);
		}
		
		System.out.println(mypony);
		System.out.println(mypony.getSize());
		
		mypony.pop();
		mypony.pop();
		mypony.pop();
		System.out.println(mypony);
		System.out.println(mypony.getSize());
		
		mypony.clear();
		System.out.println(mypony);
		System.out.println(mypony.getSize());
		
		for (int i = 0; i < 22; i++)
		{
			mypony.push(i);
		}
		
		System.out.println(mypony);
		System.out.println(mypony.getSize());
		
		//System.out.println(mypony);
	}
	
}
