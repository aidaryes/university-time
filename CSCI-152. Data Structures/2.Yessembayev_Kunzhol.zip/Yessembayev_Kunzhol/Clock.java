
package clock;

public class Clock {
    // Fields
    private int hours;
    private int minutes;
    private int seconds;
    // Constructor
    public Clock(int h, int m, int s) {
        if(h>=0 && h<24 && m>=0 && m<60 && s>=0 && s<60){
        hours = h; minutes = m; seconds = s;}
        else{
            hours = 0;
            minutes = 0;
            seconds = 0;
        }
    }
    // Reset method
    public void resetToMidnight() {
        hours = 0; minutes = 0; seconds = 0;
    }
    // Check if morning method
    public boolean isMorning() {
        return hours > 12;
    }
    // Advance one second method
    public void tick() {
        seconds++;
        if (seconds >= 60) {
            seconds = 0;
            // need to increment mins, etc.
            minutes++;
            if(minutes>=60){
                minutes=0;
                hours++;
            }
        }
        
        
    }
    
    public int getHours(){
        return hours;
    }
    
    public void setHours(int h){
        if(h>=0 && h<24){
        hours = h;}
    }
    public int getMinutes(){
        return minutes;
    }
    
    public void setMinutes(int m){
        if(m>=0 && m<60){
        minutes = m;}
    }
    public int getSeconds(){
        return seconds;
    }
    
    public void setSeconds(int s){
        if(s>=0 && s<60){
        seconds = s;}
    }
    
    
    public String toString(){
        String hrs = hours + "";
        String mnt = minutes + "";
        String scs = seconds + "";
        
        if (hours < 10)
        {
            hrs = "0" + hrs;
        }
        
        if (minutes < 10)
        {
            mnt = "0" + mnt;
        }
        
        if (seconds < 10)
        {
            scs = "0" + scs;
        }
        
        return hrs + ":" + mnt + ":" + scs;
    }
}
