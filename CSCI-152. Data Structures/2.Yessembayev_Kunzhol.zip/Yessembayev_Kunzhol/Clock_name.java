
package clock;


public class Clock_name {
    public static void main(String[] args) {
        Clock clock_start = new Clock(12, 23, 56);
        System.out.println(clock_start);
        
        clock_start.setHours(16);
        clock_start.setMinutes(59);
        clock_start.setSeconds(59);
        System.out.println(clock_start);
        
        System.out.print(clock_start.getHours()+":");
        System.out.print(clock_start.getMinutes()+":");
        System.out.println(clock_start.getSeconds());
        
        clock_start.tick();
        System.out.println(clock_start);
        
        
    }
}
