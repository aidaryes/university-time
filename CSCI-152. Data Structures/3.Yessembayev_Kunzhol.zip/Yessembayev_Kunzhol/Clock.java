
package clock;

public class Clock {
    // Fields
    private int hours;
    private int minutes;
    private int seconds;
    private String name;
    // Constructors
    
    public Clock(String new_name){
        name = new_name;
        hours = 0;
        minutes = 0;
        seconds = 0;
    }
    public Clock(int h, int m, int s, String new_name) throws Exception {
        name = new_name;
        if(h<0 || h>23 || m<0 || m>59 || s<0 || s>59){
            throw new Exception("In "+name+" time is not in range");
        }
        hours = h; minutes = m; seconds = s;
    }
    
       
    /**
     * @return the hours
     */
    public int getHours() {
        return hours;
    }

    /**
     * Values in this field have to be between 0 and 24 inclusive
     * Otherwise, an exception is thrown
     * @param hours the hours to set
     * @throws Exception, when current value is not in the range
     */
    public void setHours(int hours) throws Exception {
        if(hours < 0 || hours > 23){
            throw new Exception("In "+name+" hour is not in range");
        }
        this.hours = hours;
    }

    /**
     * @return the minutes
     */
    public int getMinutes() {
        return minutes;
    }

    /**
     * Values in this field have to be between 0 and 59 inclusive
     * Otherwise, an exception is thrown
     * @param minutes the minutes to set
     * @throws Exception, when current value is not in the range
     */
    public void setMinutes(int minutes) throws Exception{
        if(minutes < 0 || minutes > 59){
            throw new Exception("In "+name+" minutes is not in range");
        }
        this.minutes = minutes;
    }

    /**
     * @return the seconds
     */
    public int getSeconds() {
        return seconds;
    }

    /**
     * Values in this field have to be between 0 and 59 inclusive
     * Otherwise, an exception is thrown
     * @param seconds the seconds to set
     * @throws Exception, when current value is not in the range
     */
    public void setSeconds(int seconds) throws Exception {
        if(seconds < 0 || seconds > 59){
            throw new Exception("In "+name+" seconds is not in range");
        }
        this.seconds = seconds;
    }
    
    @Override
    public String toString(){
        return "In "+this.name+" "+this.hours+":"+this.minutes+":"+this.seconds;
    }
}