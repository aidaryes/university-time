
package clock;


public class Clock_name {
    public static void main(String[] args) {
            
        try {
            Clock c = new Clock(44, 55, 56, "First clock");
            System.out.println(c);
        }
        catch (Exception ex){
            System.out.println(ex.getMessage());
        }
            
            Clock cl = new Clock("Second clock");
        try{
            cl.setHours(56);
        }
        catch(Exception excep){
            System.out.println(excep.getMessage());
        }
        try{
            cl.setMinutes(556);
        }
        catch(Exception excep){
            System.out.println(excep.getMessage());
        }
        try{
            cl.setSeconds(556);
        }
        catch(Exception excep){
            System.out.println(excep.getMessage());
        }
        
        try{
            Clock clock = new Clock("Third clock");
            System.out.println(clock);
        }
        catch(Exception exception){
            System.out.println(exception.getMessage());
        }
        
    }
}
