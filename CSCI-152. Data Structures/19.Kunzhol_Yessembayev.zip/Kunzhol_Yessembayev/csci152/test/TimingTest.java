package csci152.test;
import csci152.adt.*;
import csci152.impl.*;
import java.util.Random;

public class TimingTest {

	public static void main(String[] args) {
	    
            Random rand = new Random();
            
	     HashTableSet<Integer> set = new LLQHashTableSet<>(100);

	     System.out.println("Starting timing tests...");
	     long time1, time2, duration;
	     time1 = System.currentTimeMillis();
	     
	    for (int i =0; i < 500000; i++)
            {
	          set.add(rand.nextInt());
            }
	   
	     time2 = System.currentTimeMillis();
	     duration = time2 - time1;

	     System.out.println("Time taken in ms: " + duration);
	     System.out.println(set.getLoadFactor());
	     System.out.println(set.getBucketSizeStandardDev());
	}

}
