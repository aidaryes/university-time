
package bank;

public class Bank {
    
    
    private int i = 0;
    Account[] accounts;
    
    public Bank()
    {
    	accounts = new Account[10];
    	
    	for (int j = 0; j < accounts.length; j++)
    	{
    		accounts[j] = null;
    	}
    }
    
    private Account CheckAccNum(long accountNum)
    {
    	
    	for (int j = 0; j < accounts.length; j++)
    	{
    		if (accounts[j] != null)
    		{
    			if (accounts[j].getAccountNum() == accountNum)
    			{
    				return accounts[j];
    			}
    		}
    	}
    	
		return null;
    }
    
    public void AddSavings(long accountNum, int monthRate) throws Exception
    {
    	if (CheckAccNum(accountNum) != null || monthRate < 0)
    	{
    		throw new Exception("SVN_ERR: Current Account Number is already in database or you've added monthly rate as negative value");
    	}
    	
    	accounts[i] = new Savings(accountNum, monthRate);
    	i++;
    }
    
    public void AddChecking(long accountNum) throws Exception
    {
    	if (CheckAccNum(accountNum) != null)
    	{
    		throw new Exception("CHK_ERR: Current Account Number is already in database");
    	}
    	
    	accounts[i] = new Checking(accountNum);
    	i++;
    }
    
    public void AddCredit(long accountNum, int debtLimit) throws Exception
    {
    	if (CheckAccNum(accountNum) != null || debtLimit < 0)
    	{
    		throw new Exception("CRD_ERR: Current Account Number is already in database or you've added debt limit as negative value");
    	}
    	
    	accounts[i] = new Credit(accountNum, debtLimit);
    	i++;
    }
    
    public void AddDeposit(long accNum, int money) throws Exception
    {
    	if (CheckAccNum(accNum) == null || money < 0)
    	{
    		throw new Exception("ADD_DEP_ERR: Your Account Number is not in database");
    	}
    	
    	CheckAccNum(accNum).Deposit(money);
    		
    }
    
    public void WithdrawDeposit(long accNum, int money) throws Exception
    {
    	if (CheckAccNum(accNum) == null || money < 0)
    	{
    		throw new Exception("WTH_DEP_ERR: Your Account Number is not in database");
    	}
    	
    	CheckAccNum(accNum).Withdraw(money);
    		
    }
    
    public void AccrualOnEach()
    {
    	for (int j = 0; j < accounts.length; j++)
    	{
    		if (accounts[j] != null)
    		{
    			accounts[j].MonthlyAccrual();
    		}
    	}
    }
    
    public String toString()
    {
    	String toReturn = "";
    	
    	for(int j = 0; j < accounts.length; j++)
    	{
    		if (accounts[j] != null)
    		{
    			toReturn += accounts[j].toString() + "\n";
    		}
    	}
    	
    	return toReturn;
    }
}
