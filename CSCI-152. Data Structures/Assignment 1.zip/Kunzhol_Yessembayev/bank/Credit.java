
package bank;

public class Credit extends AccountImpl{
    
    int debtLimit;
    
    public Credit(long accNum, int dbLim)
    {
    	super(accNum);
    	
    	debtLimit = dbLim;
    }
    
    //@Override
    public void Withdraw(int value) throws Exception
    {
        if (getCurrentBal() < debtLimit * -1 || getCurrentBal() + debtLimit < value)
        {
            throw new Exception("Your exceeded your debt limit");
        }
        
        setCurrentBal(getCurrentBal() - value);
    }
    
    //@Override
    public void MonthlyAccrual(){
        setCurrentBal(getCurrentBal() + getCurrentBal()/10);
    }
    
    //@Override
    public String toString(){
    	return "Type: Credit; Account Number: " + getAccountNum() + "; Balance: " + getCurrentBal() + ";";
    }
}
