
package bank;

public class Checking extends AccountImpl{
    
    int withdrawNum=0;
    
    public Checking(long accNum)
    {
    	super(accNum);
    }
    
    //@Override
    public void Withdraw(int value) throws Exception
    {
        super.Withdraw(value);
        
        withdrawNum++;
        
        if (withdrawNum > 3)
        {
            setCurrentBal(getCurrentBal() - value / 100);
        }
    }
    
    //@Override
    public void MonthlyAccrual()
    {
        super.MonthlyAccrual();
        
        withdrawNum = 0;
    }
        
    //@Override
    public String toString(){
    	return "Type: Checking; Account Number: " + getAccountNum() + "; Balance: " + getCurrentBal() + ";";
    }
}
