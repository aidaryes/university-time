
package bank;

public class AccountImpl implements Account {
    
    private long accountNum;
    private int currentBal = 0;
    
    public AccountImpl(long accNum)
    {
    	accountNum = accNum;
    }
    
    //@Override
    public void Deposit(int value) {
       setCurrentBal(getCurrentBal() + value);
    }
    
    //@Override
    public void Withdraw(int value) throws Exception {
       if (getCurrentBal() <= 0 || getCurrentBal() < value)
       {
           throw new Exception("Insufficient funds on your account");
       }
        
       setCurrentBal(getCurrentBal() - value);
    }
    
    //@Override
    public void MonthlyAccrual() {
        
    }

	public long getAccountNum() {
		return accountNum;
	}

	public int getCurrentBal() {
		return currentBal;
	}

	public void setCurrentBal(int currentBal) {
		this.currentBal = currentBal;
	}

}