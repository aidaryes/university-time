
package bank;

public class Test {
    public static void main(String[] args) {
    	
    	Bank test = new Bank();
    	
    	try
    	{
	    	test.AddSavings(123456, 2);
	    	test.AddCredit(123455, 2000);
	    	test.AddChecking(123454);
	    	
	    	//Test on exceptions
	    	
	    	//How to test exceptions
	    	//Uncomment one of the lines to test
	    	
	    	//test.AddSavings(123456, 2); //Check if can add same account number
	    	//test.AddCredit(123455, 2000); //Check if can add same account number
	    	//test.AddChecking(123454); //Check if can add same account number
	    	
	    	//test.AddSavings(123456, -2); //Check if in Saving account can make negative interest rate
	    	//test.AddCredit(123455, -2000); //Check if in Credit account can make negative debt limit
	    	
	    	//test.WithdrawDeposit(123456, 500); //Check if can withdraw from empty account in Savings
	    	//test.WithdrawDeposit(123455, 2500); //Check if can withdraw from empty account in Credit
	    	//test.WithdrawDeposit(123454, 300); //Check if can withdraw from empty account in Checking
    	
    	
    	
    	
	    	//test.AddDeposit(123456, 1000); 
	    	//test.WithdrawDeposit(123456, 1200); //Check if can withdraw more than account has
	    	
	    	//------------------------------
	    	
	    	test.AddDeposit(123456, 3000); //Check adding deposit to Saving
	    	test.WithdrawDeposit(123456, 1000); //Check withdrawing from Saving
	    	
	    	test.AddDeposit(123455, 500); //Check adding deposit to Credit
	    	test.WithdrawDeposit(123455, 800); //Check limit of Credit
	    	
	    	test.AddDeposit(123454, 5000); //Check adding deposit to Checking
	    	
	    	
	    	test.WithdrawDeposit(123454, 1000);
	    	test.WithdrawDeposit(123454, 200);
	    	test.WithdrawDeposit(123454, 700);
	    	
	    	//Check fee after 3rd withdrawal
	    	test.WithdrawDeposit(123454, 2000);
	    	
	    	System.out.println(test);
	    	
	    	//Check AccrualOnEach()
	    	//Note: interest is added to Savings account
	    	//Note: negative balance is taxed
	    	test.AccrualOnEach();
	    	
	    	//Check if number of withdrawals reseted, and withdrawling is not taxed
	    	test.WithdrawDeposit(123454, 500);
	    	
	    	
    	}
    	catch (Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	
    	
    	System.out.println(test);
    
    }
}
