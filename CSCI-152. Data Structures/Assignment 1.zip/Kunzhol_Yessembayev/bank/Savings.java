
package bank;

public class Savings extends AccountImpl {
    
    int monthlyIntRate;
    
    public Savings(long accNum, int mIR)
    {
    	super(accNum);
    	monthlyIntRate = mIR;
    }
    
    //@Override
    public void MonthlyAccrual()
    {
        setCurrentBal(getCurrentBal() + (getCurrentBal() * monthlyIntRate) / 100);
    }
    
    //@Override
    public String toString(){
        return "Type: Savings; Account Number: " + getAccountNum() + "; Balance: " + getCurrentBal() + ";";
    }
    
}
