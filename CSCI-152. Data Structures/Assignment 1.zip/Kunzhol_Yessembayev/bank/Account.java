
package bank;

public interface Account {
    
    /*@param value: add given value from the current balance
     */
    public void Deposit(int value);
    
    /*@param value: subtract given value from the current balance 
     */
    public void Withdraw(int value) throws Exception;
    
    /*@param value: updates all bank accounts and applies corresponding behavior
     */
    public void MonthlyAccrual();
    
    /*@param value: gets current balance, here is getter
     */
    public int getCurrentBal();
    
    /*@param value: gets account number, here is also getter
     */
    public long getAccountNum();
    
}