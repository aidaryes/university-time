/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_4;

import csci152.adt.HashTableMap;
import csci152.adt.Map;
import csci152.adt.Queue;
import csci152.adt.SortedQueue;
import csci152.impl.LLQHashTableMap;
import csci152.impl.LinkedListQueue;
import csci152.impl.LinkedListSortedQueue;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @authors
 * Danyshbek Assylbek
 * Yessembayev Aidar
 */
public class Assignment_4 {

    public static Queue<File> getAllFiles(File rootDir)
    {
        
        if (rootDir.isFile())
        {
            Queue<File> q = new LinkedListQueue();
            q.enqueue(rootDir);
            return q;
        }
        Queue<File> t = new LinkedListQueue();
        File[] files = rootDir.listFiles();
        for(File file: files )
        {   
            Queue<File> g = getAllFiles(file);
            while( g.getSize() > 0 )
            try
            {
                t.enqueue(g.dequeue());
            }
            catch (Exception ex){}
        }
        return t;
    }
    public static void AddIfUnique( SortedQueue<String> s, String value )
    {
        SortedQueue<String> temp = new LinkedListSortedQueue();
        boolean found = false;
        while( s.getSize() > 0)
        {
            try {
                String de = s.dequeue();
                
                temp.insert(de);
                
                if( de.equals(value) )
                {
                    found = true;
                }
                
            } catch (Exception ex) {
                Logger.getLogger(Assignment_4.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        while( temp.getSize() > 0 )
        {
            try {
                s.insert(temp.dequeue());
            } catch (Exception ex) {
                Logger.getLogger(Assignment_4.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        if(!found)
        {
            s.insert(value);
        }
    }
        
    public static int Tokenization ( Map<String, Queue<OccurrenceRecord>> t, File f, SortedQueue<String> s ) throws FileNotFoundException, IOException
    {
        BufferedReader reader =
                        new BufferedReader(new FileReader(f));

        int ch;
        int line = 1;
        int col = 0;
        int total = 0;
        String prevLine = "";
        String token = "";
        String temp = "";
        do {
            ch = reader.read();
            temp += (char)ch;
            temp = temp.toLowerCase();
            if( (ch<'A' || (ch>'Z' && ch <'a') || ch>'z') && (ch != '-' && ch != '`'))
            {
                if (token.length() > 0) {
                    token = token.toLowerCase();
                    Queue<OccurrenceRecord> or = t.remove(token);
                    if( or == null )
                    {
                        or = new LinkedListQueue();                        
                    }
                    col = col + 1 - token.length();
                    or.enqueue(new OccurrenceRecord(f.getName(), line, col));
                    t.define(token, or);
                    AddIfUnique(s, token);
                    total ++ ;
                    token = "";
                } 
                if( ch == '\n' )
                {
                    line++;
                    col = 0;
                    temp = "";
                }

            } else {
                    token = token + (char)ch;
                    if("".equals(temp))
                    {
                        col = 0;
                    }
                    else
                    {
                        col = temp.length();
                    }
                    
            }
        } while (ch != -1);
        return total;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        BufferedReader reader = null;
        try {
            File dir = new File("inputfiles");
            SortedQueue<String> sq = new LinkedListSortedQueue();
            int total = 0;
            Queue<File> q = getAllFiles(dir);
            HashTableMap<String, Queue<OccurrenceRecord>> map = new LLQHashTableMap();
            while(q.getSize() > 0)
            {
                try {
                    total += Tokenization( map, q.dequeue(), sq );
                } catch (Exception ex) {
                    Logger.getLogger(Assignment_4.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            System.out.println(map);
            System.out.println("-------------Output of SortedQueue-------------");
            while( sq.getSize() > 0 )
            {
                try {
                    System.out.println(sq.dequeue());
                } catch (Exception ex) {
                    Logger.getLogger(Assignment_4.class.getName()).log(Level.SEVERE, null, ex);
                }
            }   System.out.println("-------------Output of LoadFactor and Bucket Size Standard Deviation-------------");
            System.out.println("LoadFactor: "+map.getLoadFactor());
            System.out.println("BucketSize Standart Deviation: "+map.getBucketSizeStandardDev());
            System.out.println("-------------getwordinfo.txt-------------");
            File read = new File("getwordinfo.txt");
            reader = new BufferedReader(new FileReader(read));
            String line = "";
            while( (line=reader.readLine()) != null)
            {
                String m = "";
                line = line.trim();
                line = line.toLowerCase();
                m += "1. " + line + "\n";
                Queue<OccurrenceRecord> q1 = map.getValue(line);
                if( q1 == null )
                {
                    m += "2. Not found \n";
                }
                else
                {
                    m += "2. " + q1.toString() + "\n";
                }
                
                if( q1 == null )
                {
                    m += "3. Total number: 0 \n Frequency: 0";
                }
                else
                {
                    m += "3. Total number: "+q1.getSize()+
                            " \n Frequency: " + ((double)q1.getSize()/(double)total)*100;
                }
                
                System.out.println(m);
                System.out.println("NEXT -->");
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Assignment_4.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Assignment_4.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                reader.close();
            } catch (IOException ex) {
                Logger.getLogger(Assignment_4.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
