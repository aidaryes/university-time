/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_4;

/**
 *
 * @author Assylbek
 */
public class OccurrenceRecord
{
    private String fileName;
    private int lineN;
    private int colN;
    
    public OccurrenceRecord( String fileName, int lineN, int colN )
    {
        this.fileName = fileName;
        this.lineN = lineN;
        this.colN = colN;
    }

    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * @return the lineN
     */
    public int getLineN() {
        return lineN;
    }

    /**
     * @param lineN the lineN to set
     */
    public void setLineN(int lineN) {
        this.lineN = lineN;
    }

    /**
     * @return the colN
     */
    public int getColN() {
        return colN;
    }

    /**
     * @param colN the colN to set
     */
    public void setColN(int colN) {
        this.colN = colN;
    }
    
    @Override
    public String toString()
    {
        return "\nFile Name: " + fileName +
                "; Line Number: " + lineN + "; Collumn number: " + colN;
    }
}
