/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.adt;

/**
 *
 * @author Assylbek
 * @param <T> a generic queue
 */
public interface Queue<T> 
{
    /**
     * Adds a give value to the end of a queue
     * @param value 
     */
    public void enqueue(T value);
    
    /**
     * 
     * @return the value on the front of queue
     * @throws Exception if the queue is empty
     */
    public T dequeue() throws Exception;
    
    /**
     * 
     * @return the size of a queue
     */
    public int getSize();
    
    /**
     * Removes elements from an array
     */
    public void clear();
    
    @Override
    /**
     * @return String value of an element
     */
    public String toString();
}
