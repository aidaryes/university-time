/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.adt;

/**
 *
 * @author Assylbek
 */
public interface Deque<T>
{
    public void pushToFront(T value);
    public void pushToBack(T value);
    
    public T popFromFront() throws Exception;
    public T popFromBack() throws Exception;
    
    public int getSize();
    public void clear();
    
    @Override
    public String toString();
}
