/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.adt;

/**
 *
 * @author Assylbek
 * @param <T>
 */
public interface SortedQueue<T extends Comparable> 
{

    /**
     *
     * @param value
     */
    public void insert( T value );
    
    /**
     *
     * @return
     */
    public T dequeue() throws Exception;
    
    /**
     *
     * @return
     */
    public int getSize();
    
    /**
     *
     */
    public void clear();
    
    /**
     *
     * @return
     */
    @Override
    public String toString();
}
