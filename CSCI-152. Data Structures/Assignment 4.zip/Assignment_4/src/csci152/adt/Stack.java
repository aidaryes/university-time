/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.adt;

/**
 *
 * @author Assylbek
 * @param <T>
 */
public interface Stack<T>
{
    /**
     * 
     * @param value added at the top
     */
    public void push(T value);
    /**
     * Removes and returns the most top element
     * @return the top most element
     * @throws Exception if stack is empty
     */
    public T pop() throws Exception;
    /**
     * 
     * @return the size of the stack 
     */
    public int getSize();
    /**
     * Removes elements from the stack
     */
    public void clear();
    /**
     * 
     * @return String representation of stack
     */
    @Override
    public String toString();
}
