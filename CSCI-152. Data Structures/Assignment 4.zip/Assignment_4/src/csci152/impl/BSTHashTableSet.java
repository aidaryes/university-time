/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.impl;

import csci152.adt.HashTableSet;
/**
 *
 * @author Assylbek
 * @param <T>
 */
public class BSTHashTableSet<T extends Comparable>
        implements HashTableSet<T>
{
    
    private BSTSet<T>[] buckets;
    private int size;
    
    public BSTHashTableSet( int numBuckets )
    {
        buckets = new BSTSet[numBuckets];
        for(int i=0; i<buckets.length; i++)
        {
            buckets[i] = null;
        }
        size = 0;
    }
    
    public BSTHashTableSet()
    {
        buckets = new BSTSet[10];
        for(int i=0; i<buckets.length; i++)
        {
            buckets[i] = null;
        }
        size = 0;
    }
    
    @Override
    public void add(T value) 
    {
        if(contains(value))
        {
            return;
        }
        
        int buck = Math.abs( value.hashCode() ) % buckets.length;
        
        if( buckets[buck] == null )
        {
            buckets[buck] = new BSTSet();
        }
        
        buckets[buck].add(value);
        size ++;
    }

    @Override
    public boolean contains(T value) 
    {        
        if(size == 0)
        {
            return false;
        }
        
        int index = Math.abs( value.hashCode() ) % buckets.length;
        
        if( buckets[index] == null )
        {
            return false;
        }
        
        return buckets[index].contains(value);
    }

    @Override
    public boolean remove(T value)
    {
        if( !contains(value) )
        {
            return false;
        }
        
        int index = Math.abs( value.hashCode() ) % buckets.length;
        buckets[index].remove(value);
        
        if(buckets[index].getSize() == 0)
        {
            buckets[index] = null;
        }
        
        size -- ;
        return true;
    }

    @Override
    public T removeAny() throws Exception 
    {
        if( size == 0 )
        {
            throw new Exception("No elements!");
        }
        
        T value = null;
        
        for( int i=0; i<buckets.length; i++ )
        {
            if( buckets[i] != null )
            {
                value = buckets[i].removeAny();
                
                if(buckets[i].getSize() == 0)
                {
                    buckets[i] = null;
                }
                break;
            }
        }
        
        size -- ;
        return value;
    }

    @Override
    public int getSize() 
    {
        return size;
    }

    @Override
    public void clear() 
    {
        buckets = new BSTSet[10];
        size = 0;
    }
    
    @Override
    public String toString()
    {
        String m = "";
        m += "printing Set >> ";
        for(int i=0; i<buckets.length; i++)
        {
            if( buckets[i] != null )
            {
                m += buckets[i].toString();
            }
        }
        m += " << finished Set!";
        return m;
    }
    
    @Override
    public int getNumberOfBuckets() 
    {
        return buckets.length;
    }

    @Override
    public int getBucketSize(int index) throws Exception 
    {
        if( index >= buckets.length || index < 0 )
        {
            throw new Exception("Index Out Of Range!");
        }
        
        return buckets[index].getSize();
    }

    @Override
    public double getLoadFactor() 
    {
        double load = (double)size/(double)buckets.length;
        return load;
    }

    @Override
    public double getBucketSizeStandardDev() 
    {
        if(size == 0)
        {
            return 0;
        }
        
        double sum = 0;
        double average;
        double squaredSum = 0;
        double squaredAvg;
        double result;
        
        for(int i=0; i<buckets.length; i++)
        {
            sum += buckets[i].getSize();
        }
        average = sum/(double)buckets.length;
        
        for( int i=0; i<buckets.length; i++ )
        {
            squaredSum += Math.pow((buckets[i].getSize() - average),2);
        }
        squaredAvg = squaredSum/buckets.length;
        
        result = Math.sqrt(squaredAvg);
        
        return result;
    }

    @Override
    public String bucketsToString() 
    {
        String m = "";
        m += "printing Set ... \n";
        for (int i=0; i<buckets.length; i++)
        {
            if (buckets[i] != null) 
            {
                m += "Bucket #" + (i+1) + ". " + buckets[i].toString() + "\n";
            }
        }
        m += "finished Set!\n";
        return m;
    }
    
}
