/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.impl;

import csci152.adt.Set;
/**
 *
 * @author Assylbek
 */
public class BSTSet<T extends Comparable> implements Set<T>
{
    private TreeNode<T> root;
    private int size;
    
    public BSTSet()
    {
        root = null;
        size = 0;
    }

    @Override
    public void add(T value) 
    {
        TreeNode<T> x = new TreeNode(value);
        if( !contains(value))
        {
            if( size == 0 )
            {
                root = x;
            }
            else
            {
                TreeNode<T> temp = root;
                
                while(true)
                {
                    if( value.compareTo(temp.getValue()) < 0 )
                    {
                        if( value.compareTo(temp.getValue()) < 0 && temp.getLeft() == null )
                        {
                            temp.setLeft(x);
                            break;
                        }
                        else if( value.compareTo(temp.getValue()) > 0 && temp.getRight()== null )
                        {
                            temp.setRight(x);
                            break;
                        }
                        else
                        {
                            temp = temp.getLeft();
                        }
                    }
                    else
                    {
                        if( value.compareTo(temp.getValue()) < 0 && temp.getLeft() == null )
                        {
                            temp.setLeft(x);
                            break;
                        }
                        else if( value.compareTo(temp.getValue()) > 0 && temp.getRight()== null )
                        {
                            temp.setRight(x);
                            break;
                        }
                        else
                        {
                            temp = temp.getRight();
                        }
                    }
                }
            }
        
            size ++;
        }
    }

    @Override
    public boolean contains(T value)
    {
        if(size == 0 )
        {
            return false;
        }
        
        TreeNode<T> temp = root;
        
        return containHelper(temp, value);
    }

    private boolean containHelper( TreeNode<T> temp, T value )
    {
        if( temp == null )
        {
            return false;
        }
        
        while(temp != null)
        {
            if( value.compareTo(temp.getValue()) < 0 )
            {
                temp = temp.getLeft();
            }
            else if( value.compareTo(temp.getValue()) > 0 )
            {
                temp = temp.getRight();
            }
            else
            {
                return true;
            }
        }
        
        return false;
    }
    
    @Override
    public boolean remove(T value) 
    {
        if( !contains(value) )
        {
            return false;
        }
        
        if( size == 1 )
        {
            root = null;
        }
        else
        {
            TreeNode<T> temp = root;
            TreeNode<T> parent = temp;
            while(true)
            {
                if( value.compareTo(temp.getValue()) < 0 )
                {
                    parent = temp;
                    temp = temp.getLeft();
                }
                else if(  value.compareTo(temp.getValue()) > 0 )
                {
                    parent = temp;
                    temp = temp.getRight();
                }
                else
                {
                    if(temp.getRight() == null && temp.getLeft() != null)
                    {
                        if(parent.getLeft() == temp)
                        {
                            parent.setLeft(temp.getLeft());
                        }
                        if(parent.getRight() == temp)
                        {
                            parent.setRight(temp.getLeft());
                        }
                    }
                    if(temp.getRight() != null && temp.getLeft() == null)
                    {
                        if(parent.getLeft() == temp)
                        {
                            parent.setLeft(temp.getRight());
                        }
                        if(parent.getRight() == temp)
                        {
                            parent.setRight(temp.getRight());
                        }
                    }
                    if( temp.getLeft() == null && temp.getRight() == null )
                    {
                        if(parent.getLeft() == temp)
                        {
                            parent.setLeft(null);
                        }
                        if(parent.getRight() == temp)
                        {
                            parent.setRight(null);
                        }
                    }
                    if( temp.getRight() != null && temp.getLeft() != null )
                    {
                        TreeNode<T> temp2 = temp;
                        while( temp2.getLeft().getLeft() != null )
                        {
                            temp2 = temp2.getLeft();
                        }
                        T min = temp2.getLeft().getValue();
                        TreeNode<T> x = temp2.getLeft().getRight();
                        temp2.setLeft(x);
                        temp.setValue(min);
                    }
                    break;
                }
                
            }
        }
        
        size -- ;
        return true;
    }

    @Override
    public T removeAny() throws Exception 
    {
        T y = null;
        if( size == 0 )
        {
            throw new Exception("No elements!");
        }
        
        if( size == 1 )
        {
            T x = root.getValue();
            root = null;
            size --;
            return x;
        }
        else
        {
            TreeNode<T> x = root;
            
            while( x != null )
            {
                if( x.getRight() == null && x.getLeft() == null )
                {
                    y = x.getValue();
                    remove(x.getValue());
                    size++;
                    break;
                }
                else if( x.getRight() != null )
                {
                    x = x.getRight();
                }
                else
                {
                    x = x.getLeft();
                }
            }
        }
        
        
        
        size -- ;
        return y;
    }

    @Override
    public int getSize() 
    {
        return size;
    }

    @Override
    public void clear()
    {
        root = null;
        size = 0;
    }
    
    @Override
    public String toString()
    {
        return toStringHelper(root);
    }
    
    private String toStringHelper(TreeNode<T> node)
    {
        if( node == null )
        {
            return "";
        }
        
        return toStringHelper(node.getLeft()) + " " + 
                node.getValue()+ " " + 
                toStringHelper(node.getRight());
    }
}
