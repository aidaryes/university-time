/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.impl;

import csci152.adt.Stack;
/**
 *
 * @author Assylbek
 */
public class LinkedListStack<T> implements Stack<T>
{
    private Node<T> top;
    private int size;
    
    public LinkedListStack()
    {
        top = null;
        size = 0;
    }
    
    @Override
    public void push(T value) 
    {
        Node<T> node1 = new Node(value);
        node1.setLink(top);
        top = node1;
        
        size ++ ;
    }

    @Override
    public T pop() throws Exception
    {
        if(size == 0)
        {
            throw new Exception("No elements to pop.");
        }
        
        T result = top.getValue();
        top = top.getLink();
        size -- ;
        return result;
    }

    @Override
    public int getSize()
    {
        return size;
    }

    @Override
    public void clear() 
    {
        top = null;
        size = 0;
    }
    
    @Override
    public String toString()
    {
        String m = "{ ";
        int i = 0;
 
        Node<T> n = new Node(0);
        n = top;
        while( n != null )
        {
//            if( i == 0 )
//            {
//                n = new Node(top.getValue());
//                n.setLink(top.getLink());   
//            }
//            i++;
            m += n.getValue() + "; ";
            
            n = n.getLink();
//            if( i == size-1 )
//            {
//                top.setValue(n.getValue());
//                top.setLink(n.getLink());
//            }            
        }
        
        return m += " }";
//        return top.toString();
    }
}
