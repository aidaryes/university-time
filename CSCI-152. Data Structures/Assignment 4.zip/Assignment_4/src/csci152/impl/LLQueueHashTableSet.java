/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.impl;
import csci152.adt.HashTableSet;
/**
 *
 * @author Assylbek
 * @param <T>
 */
//COMPARABLE
public class LLQueueHashTableSet<T> implements HashTableSet<T>
{
    private LinkedListQueue<T>[] buckets;
    private int size;
    
    public LLQueueHashTableSet()
    {
        buckets = new LinkedListQueue[10];
        for(int i=0; i<buckets.length; i++)
        {
            buckets[i] = null;
        }
        size = 0;
    }
    
    public LLQueueHashTableSet( int s )
    {
        buckets = new LinkedListQueue[s];
        for(int i=0; i<buckets.length; i++)
        {
            buckets[i] = null;
        }
        size = 0;
    }
    
    @Override
    public void add(T value)
    {
        int buck = Math.abs( value.hashCode() ) % buckets.length;
        
        if( contains(value) )
        {
            return;
        }
        
        if( buckets[buck] == null )
        {
            buckets[buck] = new LinkedListQueue();
        }
        
        buckets[buck].enqueue(value);
        
        size ++;
    }

    @Override
    public boolean contains(T value) 
    {
        boolean found = false;
        
        if(size == 0)
        {
            return false;
        }
        
        int index = Math.abs( value.hashCode() ) % buckets.length;
        LinkedListQueue<T> temp = new LinkedListQueue();
        
        if(buckets[index] == null)
        {
            return false;
        }
        
        while( buckets[index].getSize() > 0 )
        {
            try
            {
                T de = buckets[index].dequeue();
                if( de.equals(value) )
                {
                    found = true;
                }
                temp.enqueue(de);
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        
        while( temp.getSize() > 0 )
        {
            try
            {
                T de = temp.dequeue();
                buckets[index].enqueue(de);
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        
        return found;
    }
    
    @Override
    public boolean remove(T value) 
    {
        if( !contains(value) )
        {
            return false;
        }
        
        int index = Math.abs( value.hashCode() ) % buckets.length;
        LinkedListQueue<T> temp = new LinkedListQueue();

        while( buckets[index].getSize() > 0 )
        {
            try
            {
                T de = buckets[index].dequeue();
                if( !de.equals(value) )
                {
                    temp.enqueue(de);
                }
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        
        while( temp.getSize() > 0 )
        {
            try
            {
                T de = temp.dequeue();
                buckets[index].enqueue(de);
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        
        if(buckets[index].getSize() == 0)
        {
            buckets[index] = null;
        }
        
        size -- ;
        return true;
    }
    
    @Override
    public T removeAny() throws Exception 
    {
        if( size == 0 )
        {
            throw new Exception("No elements!");
        }
        
        T value = null;
        
        for( int i=0; i<buckets.length; i++ )
        {
            if( buckets[i] != null )
            {
                value = buckets[i].dequeue();
                
                if(buckets[i].getSize() == 0)
                {
                    buckets[i] = null;
                }
                break;
            }
        }
        
        size -- ;
        return value;
    }

    @Override
    public int getSize() 
    {
        return size;
    }

    @Override
    public void clear() 
    {
        buckets = new LinkedListQueue[10];
        for(int i=0; i<buckets.length; i++)
        {
            buckets[i] = null;
        }
        size = 0;
    }
    
    @Override
    public String toString()
    {
        String m = "";
        m += "printing Set >> ";
        for(int i=0; i<buckets.length; i++)
        {
            if( buckets[i] != null )
            {
                m += buckets[i].toString();
            }
        }
        m += " << finished Set!";
        return m;
    }
    
    @Override
    public int getNumberOfBuckets() 
    {
        return buckets.length;
    }

    @Override
    public int getBucketSize(int index) throws Exception 
    {
        if( index >= buckets.length || index < 0 )
        {
            throw new Exception("Index Out Of Range!");
        }
        
        return buckets[index].getSize();
    }

    @Override
    public double getLoadFactor() 
    {
        double load = (double)size/(double)buckets.length;
        return load;
    }

    @Override
    public double getBucketSizeStandardDev() 
    {
        if(size == 0)
        {
            return 0;
        }
        
        double sum = 0;
        double average;
        double squaredSum = 0;
        double squaredAvg;
        double result;
        
        for(int i=0; i<buckets.length; i++)
        {
            sum += buckets[i].getSize();
        }
        average = sum/(double)buckets.length;
        
        for( int i=0; i<buckets.length; i++ )
        {
            squaredSum += Math.pow((buckets[i].getSize() - average),2);
        }
        squaredAvg = squaredSum/buckets.length;
        
        result = Math.sqrt(squaredAvg);
        
        return result;
    }

    @Override
    public String bucketsToString() 
    {
        String m = "";
        m += "printing Set ... \n";
        for (int i=0; i<buckets.length; i++)
        {
            if (buckets[i] != null) 
            {
                m += "Bucket #" + (i+1) + ". " + buckets[i].toString() + "\n";
            }
        }
        m += "finished Set!\n";
        return m;
    }
}
