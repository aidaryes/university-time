/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.impl;

import csci152.adt.HashTableMap;

/**
 *
 * @author Assylbek
 */
public class LLQHashTableMap<K,V> implements HashTableMap<K,V>
{
    
    private LinkedListQueue<KeyValuePair<K,V>>[] buckets;
    private int size;
    
    public LLQHashTableMap()
    {
        buckets = new LinkedListQueue[10];
        for(int i=0; i<buckets.length; i++)
        {
            buckets[i] = null;
        }
        size = 0;
    }
    
    public LLQHashTableMap(int s)
    {
        buckets = new LinkedListQueue[s];
        for(int i=0; i<buckets.length; i++)
        {
            buckets[i] = null;
        }
        size = 0;
    }
    
    @Override
    public void define(K key, V value) 
    {
        int buck = Math.abs( key.hashCode() ) % buckets.length;
        
        if( contains(key, value) )
        {
            return;
        }
        
        if( buckets[buck] == null )
        {
            buckets[buck] = new LinkedListQueue();
        }
        
        buckets[buck].enqueue(new KeyValuePair(key,value));
        
        size ++;
    }
    
    private boolean contains( K key, V value )
    {
        boolean found = false;
        
        if(size == 0)
        {
            return false;
        }
        
        int index = Math.abs( key.hashCode() ) % buckets.length;
        
        if(buckets[index] == null)
        {
            return false;
        }
        
        for( int i=0; i<buckets[index].getSize(); i++)
        {
            try
            {
                KeyValuePair<K,V> de = buckets[index].dequeue();
                if( de.getKey().equals(key) )
                {
                    de.setValue(value);
                    found = true;
                }
                buckets[index].enqueue(de);
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        
        return found;
    }
    
    private boolean contains( K key )
    {
        boolean found = false;
        
        if(size == 0)
        {
            return false;
        }
        
        int index = Math.abs( key.hashCode() ) % buckets.length;
        
        if(buckets[index] == null)
        {
            return false;
        }
        
        for( int i=0; i<buckets[index].getSize(); i++)
        {
            try
            {
                KeyValuePair<K,V> de = buckets[index].dequeue();
                if( de.getKey().equals(key) )
                {
                    found = true;
                }
                buckets[index].enqueue(de);
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        
        return found;
    }

    @Override
    public V getValue(K key) 
    {
        V found = null;
        
        if(size == 0)
        {
            return null;
        }
        
        int index = Math.abs( key.hashCode() ) % buckets.length;
        
        if(buckets[index] == null)
        {
            return null;
        }
        
        
        for( int i=0; i<buckets[index].getSize(); i++)
        {
            try
            {
                KeyValuePair<K,V> de = buckets[index].dequeue();
                if( de.getKey().equals(key) )
                {
                    found = de.getValue();
                }
                buckets[index].enqueue(de);
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        
        return found;
    }

    @Override
    public V remove(K key) 
    {
        if( !contains(key) )
        {
            return null;
        }
        
        int index = Math.abs( key.hashCode() ) % buckets.length;
        
        V found = null;
        int n = buckets[index].getSize();
        for( int i=0; i<n; i++)
        {
            try
            {
                KeyValuePair<K,V> de = buckets[index].dequeue();
                if( de.getKey().equals(key) )
                {
                    found = de.getValue();
                }
                else
                {
                    buckets[index].enqueue(de);
                }
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        
        if(buckets[index].getSize() == 0)
        {
            buckets[index] = null;
        }
        
        size -- ;
        
        return found;
    }

    @Override
    public KeyValuePair<K,V> removeAny() throws Exception
    {
        if( size == 0 )
        {
            throw new Exception("No elements!");
        }
        
        KeyValuePair<K,V> value = null;
        
        for( int i=0; i<buckets.length; i++ )
        {
            if( buckets[i] != null )
            {
                value = buckets[i].dequeue();
                
                if(buckets[i].getSize() == 0)
                {
                    buckets[i] = null;
                }
                break;
            }
        }
        
        size -- ;
        return value;
    }

    @Override
    public int getSize() 
    {
       return size;
    }

    @Override
    public void clear() 
    {
        buckets = new LinkedListQueue[10];
        for(int i=0; i<buckets.length; i++)
        {
            buckets[i] = null;
        }
        size = 0;
    }

    @Override
    public int getNumberOfBuckets() 
    {
        return buckets.length;
    }

    @Override
    public int getBucketSize(int index) throws Exception 
    {
        if( index >= buckets.length || index < 0 )
        {
            throw new Exception("Index Out Of Range!");
        }
        
        return buckets[index].getSize();
    }

    @Override
    public double getLoadFactor() 
    {
        double load = (double)size/(double)buckets.length;
        return load;
    }

    @Override
    public double getBucketSizeStandardDev() 
    {
        if(size == 0)
        {
            return 0;
        }
        
        double sum = 0;
        double average;
        double squaredSum = 0;
        double squaredAvg;
        double result;
        
        for(int i=0; i<buckets.length; i++)
        {
            if( buckets[i] != null )
            {
                sum += buckets[i].getSize();
            }
        }
        average = sum/(double)buckets.length;
        
        for( int i=0; i<buckets.length; i++ )
        {
            if( buckets[i] != null )
            {
                squaredSum += Math.pow((buckets[i].getSize() - average),2);
            }
        }
        squaredAvg = squaredSum/buckets.length;
        
        result = Math.sqrt(squaredAvg);
        
        return result;
    }

    @Override
    public String bucketsToString() 
    {
        String m = "";
        m += "printing Set ... \n";
        for (int i=0; i<buckets.length; i++)
        {
            if (buckets[i] != null) 
            {
                m += "Bucket #" + (i) + ". " + buckets[i].toString() + "\n";
            }
        }
        m += "finished Set!\n";
        return m;
    }
    
    @Override
    public String toString()
    {
        String m = "";
        m += "printing Set >> \n";
        for(int i=0; i<buckets.length; i++)
        {
            if( buckets[i] != null )
            {
                m += buckets[i].toString() + " \n";
            }
        }
        m += "<< finished Set!";
        return m;
    }
    
}
