/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.impl;

import csci152.adt.Set;
/**
 *
 * @author Assylbek
 * @param <T>
 */
public class LLStackSet<T> implements Set<T>
{
    LinkedListStack<T> stack;
    
    public LLStackSet()
    {
        stack = new LinkedListStack<>();
    }
    
    @Override
    public void add(T value) 
    {
        if( !contains(value) )
        {
            stack.push(value);
        }
    }

    @Override
    public boolean contains(T value)
    {
        LinkedListStack<T> temp = new LinkedListStack();
        boolean logic = false;
        
        while( stack.getSize() > 0)
        {
            try
            {
                T x = stack.pop();
                temp.push(x);
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        
        while( temp.getSize() > 0)
        {
            try
            {
                T x = temp.pop();
                stack.push(x);
                
                if( x.equals(value))
                {
                    logic = true;
                }
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        return logic;
    }

    @Override
    public boolean remove(T value)
    {
        LinkedListStack<T> temp = new LinkedListStack();
        boolean logic = false;
        
        while( stack.getSize() > 0)
        {
            try
            {
                T x = stack.pop();
                temp.push(x);
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        
        while( temp.getSize() > 0)
        {
            try
            {
                T x = temp.pop();
                
                if( x.equals(value))
                {
                    logic = true;
                }
                else
                {
                    stack.push(x);
                }
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        return logic;
    }

    @Override
    public T removeAny() throws Exception 
    {
        if(stack.getSize() == 0 )
        {
            throw new Exception("REMOVE ANY ERROR: no elements!");
        }
        
        return stack.pop();

    }

    @Override
    public int getSize()
    {
        return stack.getSize();
    }

    @Override
    public void clear() 
    {
        stack = new LinkedListStack<>();
    }
    
    @Override
    public String toString()
    {
        return stack.toString();
    }
    
}
