/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.impl;

import csci152.adt.SortedQueue;
/**
 *
 * @author Assylbek
 * @param <T>
 */
public class LinkedListSortedQueue<T extends Comparable>
                    implements SortedQueue<T>
{
    private Node<T> front;
    int size;
    
    public LinkedListSortedQueue()
    {
        front = null;
        size = 0;
    }
    
    @Override
    public void insert(T value) 
    {
       Node<T> newNode = new Node(value);
       
       if(size==0)
       {
           front = newNode;
       }
       else
       {
           //newNOde goes before front
           if( value.compareTo(front.getValue()) <= 0 )
           {
               newNode.setLink(front);
               front = newNode;
           }
           else
           {
           //newNode goes in middle
                Node<T> t = front;
                while( t != null )
                {
                    if( t.getLink() == null )
                    {
                        t.setLink(newNode);
                        break;
                    }

                    if( value.compareTo(t.getLink().getValue()) <= 0 )
                    {
                        newNode.setLink(t.getLink());
                        t.setLink(newNode);
                        break;
                    }


                    t = t.getLink();

                 }
           }
           //newNode goes at the end
       }
       
       size++;
    }

    @Override
    public T dequeue() throws Exception
    {
        
        if( size == 0 )
        {
            throw new Exception("DEQUEUE ERROR: No elements in queue.");
        }
        
        T result = front.getValue();
        
        if( size == 1 )
        {
            front = null;
        }
        else
        {
            front = front.getLink();
        }
        
        size -- ;
        return result;
    }

    @Override
    public int getSize()
    {
        return size;
    }

    @Override
    public void clear() 
    {
        front = null;
        size = 0;
    }
    
    @Override
    public String toString()
    {
        String m = "front { ";
        Node<T> n = front;
        
        while( n != null )
        {
            m += n.getValue() + "; ";
            
            n = n.getLink();
        }
        
        return m += " } back";
    }
}
