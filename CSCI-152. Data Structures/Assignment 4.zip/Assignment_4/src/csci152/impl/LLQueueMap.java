/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.impl;

import csci152.adt.Map;
/**
 *
 * @author Assylbek
 */
public class LLQueueMap<K, V> implements Map<K, V>
{
    private LinkedListQueue<KeyValuePair<K,V>> pairs;
    
    public LLQueueMap() 
    {
       pairs = new LinkedListQueue();
    }
    
    @Override
    public void define(K key, V value) 
    {
       boolean found = false;
       for( int i = 0; i < pairs.getSize(); i++ )
        {
            try
            {
                KeyValuePair<K,V> x = pairs.dequeue();                
                if( x.getKey().equals(key) )
                {
                    x.setValue(value);
                    found = true;
                }
                pairs.enqueue( x );
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
       if(!found)
       {
           KeyValuePair<K,V> x = new KeyValuePair(key, value);
           pairs.enqueue(x);
       }
    }

    @Override
    public V getValue(K key)
    {
        V re = null;
        for( int i = 0; i < pairs.getSize(); i++ )
        {
            try
            {
                KeyValuePair<K,V> x = pairs.dequeue();                
                if( x.getKey().equals(key) )
                {
                    re = x.getValue();
                }
                pairs.enqueue( x );
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        return re;
    }

    @Override
    public V remove(K key) 
    {
        V re = null;
        for( int i = 0; i < pairs.getSize(); i++ )
        {
            try
            {
                KeyValuePair<K,V> x = pairs.dequeue();                
                if( x.getKey().equals(key) )
                {
                    re = x.getValue();
                }
                else
                {
                    pairs.enqueue( x );
                }
            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }
        return re;
    }

    @Override
    public KeyValuePair<K, V> removeAny() throws Exception 
    {
        if( pairs.getSize() == 0 )
        {
            throw new Exception("No elements.");
        }
        
        return pairs.dequeue();
    }

    @Override
    public int getSize() 
    {
        return pairs.getSize();
    }

    @Override
    public void clear() 
    {
       pairs = new LinkedListQueue();
    }
    
    @Override
    public String toString()
    {
        String m = "<< ";
        m += pairs.toString();
        m += " >>";
        return m;
    }
}
