/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.impl;

import csci152.adt.Queue;
/**
 *
 * @author Assylbek
 */
public class ArrayQueue<T> implements Queue<T>
{
    private T[] values;
    private int size;
    private int front;
    private int back;
    
    public ArrayQueue()
    {
        values = (T[])new Object[5];
        size = 0;
        front=0;
        back = 0;
    }
    
    @Override
    public void enqueue(T value) 
    {
        if (size < values.length)
        {
            values[back] = value;
            
            back = (back + 1) % values.length;
            size++;
        }
        else if ( size == values.length )
        {
            T[] vals = (T[])new Object[2 * values.length];
            int q = 0;
            for( int i = front; i < values.length; i++)
            {
                    vals[i - front] = values[i];
                    q = i - front + 1;
            }
            
            for( int j=0; j<back; j++ )
            {
                vals[q + j] = values[j];
            }
            
            front = 0;
            back = size;
            
            values = vals;
            
            enqueue(value);
        }
        
    }

    @Override
    public T dequeue() throws Exception 
    {
        if( size == 0 )
        {
            throw new Exception("DEQUEUE ERROR: The queue is empty.");
        }
        
        T result = values[front];
        values[front] = null;
//        if( front+1 != values.length )
//        {
//            front++; 
//        }
//        else
//        {
//            front = 0;
//        }
        
        front = (front + 1) % values.length;
        
        
        size--;
        return result;
    }

    @Override
    public int getSize() 
    {
        return size;
    }

    @Override
    public void clear() 
    {
        values = (T[])new Object[5];
        size = 0;
        front = 0;
        back = 0;
    }
    
//    @Override
//    public String toString()
//    {
//        return firstName + " " + lastName + ". ID: " + id +
//                ". Year: " + year;
//    }
    
    @Override
    public String toString()
    {
        String toReturn = "front[ ";

        if (front <= back)
        {
                for (int i = front; i < back; i++)
                {
                        toReturn += values[i].toString() + "; ";
                }
        }
        else
        {
                for (int i = front; i < values.length; i++)
                {
                        toReturn += values[i].toString() + "; ";
                }

                for (int i = 0; i < back; i++)
                {
                        toReturn += values[i].toString() + "; ";
                }
        }

        toReturn += " ]back";

        return toReturn;
    }
}
