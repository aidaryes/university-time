/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.impl;

import csci152.adt.Map;

/**
 *
 * @author Assylbek
 */
public class BSTMap< K extends Comparable, V > implements Map<K,V> 
{
    private TreeNode<KeyValuePair<K,V>> root;
    private int size;
	
    public BSTMap() {
            root = null;
            size = 0;
    }

    @Override
    public void define(K key, V value) 
    {
        // TODO Auto-generated method stub
        KeyValuePair<K,V> def = new KeyValuePair(key, value);
        
        if( containsHelper(root, def) )
        {
            return;
        }
        else
        {
            if(size == 0)
            {
                root = new TreeNode(def);
            }
            else
            {
                TreeNode<KeyValuePair<K,V>> temp = root;
                
                while(true)
                {
                    if( def.getKey().compareTo(temp.getValue().getKey()) < 0 )
                    {
                        if( def.getKey().compareTo(temp.getValue().getKey()) < 0 && temp.getLeft() == null )
                        {
                            temp.setLeft(new TreeNode(def));
                            break;
                        }
                        else if( def.getKey().compareTo(temp.getValue().getKey()) > 0 && temp.getRight()== null )
                        {
                            temp.setRight(new TreeNode(def));
                            break;
                        }
                        else
                        {
                            temp = temp.getLeft();
                        }
                    }
                    else if(def.getKey().compareTo(temp.getValue().getKey()) > 0)
                    {
                        if( def.getKey().compareTo(temp.getValue().getKey()) < 0 && temp.getLeft() == null )
                        {
                            temp.setLeft(new TreeNode(def));
                            break;
                        }
                        else if( def.getKey().compareTo(temp.getValue().getKey()) > 0 && temp.getRight()== null )
                        {
                            temp.setRight(new TreeNode(def));
                            break;
                        }
                        else
                        {
                            temp = temp.getRight();
                        }
                    }
                    else
                    {
                        temp.setValue(def);
                        size --;
                        break;
                    }
                }
            }
            size++;
        }
    }
    
    private boolean containsHelper( TreeNode<KeyValuePair<K,V>> temp, KeyValuePair<K,V> t )
    {        
        if( temp == null )
        {
            return false;
        }
        
        while( temp != null  )
        {
            if( temp.getValue().getKey().compareTo(t.getKey()) < 0 )
            {
                temp = temp.getLeft();
            }
            else if( temp.getValue().getKey().compareTo(t.getKey()) > 0 )
            {
                temp = temp.getRight();
            }
            else
            {
                temp.getValue().setValue(t.getValue());
                return true;
            }
        }
        
        return false;
    }

    @Override
    public V getValue(K key) 
    {
        TreeNode<KeyValuePair<K,V>> temp = root;

        while(true)
        {
            if( temp.getValue().getKey() == key )
            {
                return temp.getValue().getValue();
            }
            
            if( key.compareTo(temp.getValue().getKey()) < 0 )
            {
                if( key.compareTo(temp.getValue().getKey()) < 0 && temp.getLeft() == null )
                {
                    return null;
                }
                else if( key.compareTo(temp.getValue().getKey()) > 0 && temp.getRight()== null )
                {
                    return null;
                }
                else
                {
                    temp = temp.getLeft();
                }
            }
            else
            {
                if( key.compareTo(temp.getValue().getKey()) < 0 && temp.getLeft() == null )
                {
                    return null;
                }
                else if( key.compareTo(temp.getValue().getKey()) > 0 && temp.getRight()== null )
                {
                    return null;
                }
                else
                {
                    temp = temp.getRight();
                }
            }
        }
    }

    @Override
    public V remove(K key) 
    {
        
        if( size == 1 )
        {
            if( root.getValue().getKey() == key )
            {
                V re = root.getValue().getValue();
                root = null;
                size -- ;
                return re;
            }
            else
            {
                return null;
            }
        }
        else if(size == 0)
        {
            return null;
        }
        else
        {
            TreeNode<KeyValuePair<K,V>> temp = root;
            TreeNode<KeyValuePair<K,V>> parent = temp;
            while(true)
            {
                if( key.compareTo(temp.getValue().getKey()) < 0 && temp.getLeft() != null )
                {
                    parent = temp;
                    temp = temp.getLeft();
                }
                else if( key.compareTo(temp.getValue().getKey()) > 0 && temp.getRight() != null )
                {
                    parent = temp;
                    temp = temp.getRight();
                }
                else if( key.compareTo(temp.getValue().getKey()) == 0 )
                {
                    if(temp.getRight() == null && temp.getLeft() != null)
                    {
                        if(parent.getLeft() == temp)
                        {
                            parent.setLeft(temp.getLeft());
                        }
                        if(parent.getRight() == temp)
                        {
                            parent.setRight(temp.getLeft());
                        }
                        size--;
                        return temp.getValue().getValue();
                    }
                    if(temp.getRight() != null && temp.getLeft() == null)
                    {
                        if(parent.getLeft() == temp)
                        {
                            parent.setLeft(temp.getRight());
                        }
                        if(parent.getRight() == temp)
                        {
                            parent.setRight(temp.getRight());
                        }
                        size--;
                        return temp.getValue().getValue();
                    }
                    if( temp.getLeft() == null && temp.getRight() == null )
                    {
                        if(parent.getLeft() == temp)
                        {
                            parent.setLeft(null);
                        }
                        if(parent.getRight() == temp)
                        {
                            parent.setRight(null);
                        }
                        size--;
                        return temp.getValue().getValue();
                    }
                    if( temp.getRight() != null && temp.getLeft() != null )
                    {
                        V re = temp.getValue().getValue();
                        TreeNode<KeyValuePair<K,V>> temp2 = temp;
                        while( temp2.getLeft().getLeft() != null )
                        {
                            temp2 = temp2.getLeft();
                        }
                        KeyValuePair<K,V> min = temp2.getLeft().getValue();
                        TreeNode<KeyValuePair<K,V>> x = temp2.getLeft().getRight();
                        temp2.setLeft(x);
                        temp.setValue(min);
                        size--;
                        return re;
                    }
                }
                else
                {
                    break;
                }
                
            }
        }
        
        return null;
    }

    @Override
    public KeyValuePair<K, V> removeAny() throws Exception 
    {
        KeyValuePair<K, V> y = null;
        if( size == 0 )
        {
            throw new Exception("No elements!");
        }
        
        if( size == 1 )
        {
            KeyValuePair<K, V> x = root.getValue();
            root = null;
            size --;
            return x;
        }
        else
        {
            TreeNode<KeyValuePair<K, V>> x = root;
            
            while( x != null )
            {
                if( x.getRight() == null && x.getLeft() == null )
                {
                    y = x.getValue();
                    remove(x.getValue().getKey());
                    size++;
                    break;
                }
                else if( x.getRight() != null )
                {
                    x = x.getRight();
                }
                else
                {
                    x = x.getLeft();
                }
            }
        }
        
        
        
        size -- ;
        return y;
    }

    @Override
    public int getSize() {
            // TODO Auto-generated method stub
            return size;
    }

    @Override
    public void clear() {
            // TODO Auto-generated method stub
            root = null;
            size = 0;
    }

    @Override
    public String toString() {
    	// TODO Implement me!
    	return toStringHelper(root);
    }
    
    private String toStringHelper(TreeNode<KeyValuePair<K, V>> node)
    {
        if( node == null )
        {
            return "";
        }
        
        return toStringHelper(node.getLeft()) + " " + 
                node.getValue()+ " " + 
                toStringHelper(node.getRight());
    }
}
