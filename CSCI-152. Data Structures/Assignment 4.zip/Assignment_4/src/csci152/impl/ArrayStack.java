/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.impl;

import csci152.adt.Stack;

/**
 *
 * @author Assylbek
 */
public class ArrayStack<T> implements Stack<T>
{
    private T[] values;
    private int size;

    public ArrayStack()
    {
        values = (T[])new Object[10];
        size = 0;
    }
    
    @Override
    public void push(T value)
    {
        if( size < values.length )
        {
            
        }
        else
        {            
            T[] vals = (T[])new Object[values.length];
            for(int i=0; i<vals.length; i++)
            {
                vals[i] = values[i];
            }
            
            values = (T[])new Object[2*values.length];
            
            for(int i=0; i < vals.length; i++)
            {
                values[i] = vals[i];
            }
        }
        values[size] = value;
        size++;
    }

    @Override
    public T pop() throws Exception 
    {
        if(size > 0)
        {
            T result = values[size-1];
            size--;
            return result;
        }
        else
        {
            throw new Exception("POP ERROR! No values in stack!");
        }
    }

    @Override
    public int getSize() 
    {
        return size;
    }

    @Override
    public void clear() 
    {
        values = (T[])new Object[10];
        size = 0;
    }
    
    @Override
    public String toString()
    {
        if(size == 0)
        {
            return "null";
        }
        if( size == 1 )
        {
            return values[0].toString() + "; ";
        }
        String m = "";
        m += "bottom[ ";
        for(int i=0; i<size; i++)
        {
            m += values[i].toString() + "; ";
        }
        m += " ]top";
        return m;
    }
}
