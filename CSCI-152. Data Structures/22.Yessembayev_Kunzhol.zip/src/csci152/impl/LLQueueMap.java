
package csci152.impl;

import csci152.adt.KeyValuePair;
import csci152.adt.Map;

public class LLQueueMap <K, V> implements Map <K, V> {

    private LinkedListQueue<KeyValuePair<K, V>> pairs;
    private int size;
    
    public LLQueueMap(){
        pairs = new LinkedListQueue();
        size = 0;
    }
    
    @Override
    public void define(K key, V value) {
        
        boolean enqueued = false;
        
        for(int i = 0; i<pairs.getSize(); i++)
        {
            KeyValuePair temp;
            try {
                temp = pairs.dequeue();
                if(temp.getKey().equals(key))
                    {
                        temp.setValue(value);
                        enqueued = true;
                    }
                pairs.enqueue(temp);
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
        }
        
        if(!enqueued)
        {
        size++;
        pairs.enqueue(new KeyValuePair(key, value));
        }
    }

    @Override
    public V getValue(K key) {
    
        if(size==0){
            return null;
        }
        for(int i = 0; i<pairs.getSize(); i++){
            try{
                KeyValuePair val = pairs.dequeue();
                pairs.enqueue(val);
               
                if(val.getKey().equals(key)){
                    return (V)val.getValue();
                } 
            }
            catch(Exception ex){
                System.out.println(ex.getMessage());
            }
        }
        return null;
    }

    @Override
    public V remove(K key) {
        if(size==0){
            return null;
        }
        for(int i = 0; i<pairs.getSize(); i++){
            try{
                KeyValuePair val = pairs.dequeue();
                               
                if(val.getKey().equals(key)){
                    size--;
                    return (V)val.getValue();
                } 
                pairs.enqueue(val);
            }
            catch(Exception ex){
                System.out.println(ex.getMessage());
            }
        }
        return null;
    }

    @Override
    public KeyValuePair<K, V> removeAny() throws Exception {
        if(size==0){
            throw new Exception("Stack is empty");
        }
        else{
        
        KeyValuePair ret = pairs.dequeue();
        size--;
        return ret;
        }
    }

    @Override
    public int getSize() {
        return size;
    }

    @Override
    public void clear() {
        pairs = new LinkedListQueue();
        size = 0;
    }
    
    public String toString(){
        return pairs.toString();
    }
}
