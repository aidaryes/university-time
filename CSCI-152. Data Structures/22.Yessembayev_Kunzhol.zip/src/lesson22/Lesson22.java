
package lesson22;

import csci152.impl.LLQueueMap;

/**
 *
 * @author MDK
 */
public class Lesson22 {

    
    public static void main(String[] args) throws Exception {
        LLQueueMap<Integer, String> tester = new LLQueueMap();
        
        try{
        tester.removeAny();
        }
        catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        
        System.out.println(tester);
        System.out.println(tester.getSize());
        
        
        
        tester.define(1, "Arujan");
        tester.define(2, "Ai");
        tester.define(3, "Bau");
        tester.define(4, "Jak");
        tester.define(5, "Vca");
       
        System.out.println(tester);
        System.out.println(tester.getSize());
        
        tester.remove(2);
        System.out.println(tester);
        System.out.println(tester.getSize());
        
        tester.remove(20);
        System.out.println(tester);
        System.out.println(tester.getSize());
        
        tester.define(6, "NBV");
        tester.define(6, "gjj");
        System.out.println(tester);
        System.out.println(tester.getSize());
        
        tester.define(7, "CZx");
        tester.define(8, "YTU");
        tester.define(9, "JKH");
        System.out.println(tester);
        System.out.println(tester.getSize());
        
        System.out.println(tester.removeAny());
        System.out.println(tester.removeAny());
        System.out.println(tester);
        System.out.println(tester.getSize());
        
        tester.clear();
        System.out.println(tester);
        System.out.println(tester.getSize());
        
        tester.define(101, "And");
        tester.define(102, "Last");
        System.out.println(tester);
        System.out.println(tester.getSize());
        }
    }
