package csci152.impl;
import csci152.adt.IntStack;

/* Name of the class has to be "Main" only if the class is public. */
public class ArrayIntStack implements IntStack
{
    private int[] values;
    private int size;
    
    public ArrayIntStack() {
        values = new int[10];
        size = 0;
    }
    
    public void push(int value)
    {
        values[size] = value;
        size++;
        
        if (size == values.length)
        {
		int[] temp = new int[2 * size];

		for (int i = 0; i < size; i++)
		{
			temp[i] = values[i];
		}

		values = temp;
        }
    }
    
    public int pop() throws Exception
    {
        if (size == 0)
        {
            throw new Exception("Size of Stack is 0");
        }
        
        int result = values[size - 1];
        size--;
        return result;
    }
    
    public int getSize()
    {
        return size;
    }
    
    public void clear()
    {
        values = new int[10];
        size = 0;
    }
    
    public String toString()
    {
       String toReturn = "bottom ";
       
       for (int i = 0; i < size; i++)
       {
           toReturn += values[i] + " ";
       }
       
       toReturn += "top";
       
       return toReturn;
    }
}
