package csci152.impl;
import csci152.adt.IntQueue;

public class ArrayIntQueue implements IntQueue {
	
	int[] values;
	int cap;
	int size, front, back;
	
	public ArrayIntQueue()
	{
		values = new int[5];
		cap = 5;
		size = 0;
		front = 0;
		back = 0;
	}

	public void enqueue(int value) {
		
		if (size < cap)
		{
			values[back] = value;
			back = (back + 1) % cap;
			size++;
		}
		else if (size == cap)
		{
			int[] temp = new int[2 * cap];
			int tempInd = 0;
			
			for (int i = front; i < cap; i++)
			{
				temp[i - front] = values[i];
				tempInd = i - front + 1;
			}
			
			for (int i = 0; i < back; i++)
			{
				temp[tempInd + i] = values[i];
			}
			
			
			front = 0;
			back = cap;
			
			values = temp;
			cap *= 2;
			
			enqueue(value);
		}
		
	}

	public int dequeue() throws Exception {
		if (size == 0)
		{
			throw new Exception("Queue is empty");
		}
		
		int result = values[front];
		front = (front + 1) % cap;
		size--;
		
		return result;
	}

	public int getSize() {
		return size;
	}

	public void clear() {
		values = new int[5];
		cap = 5;
		size = 0;
		front = 0;
		back = 0;
		
	}
	
	public String toString()
	{
		String toReturn = "front--> ";
		
		if (front <= back)
		{
			for (int i = front; i < back; i++)
			{
				toReturn += values[i] + " ";
			}
		}
		else
		{
			for (int i = front; i < cap; i++)
			{
				toReturn += values[i] + " ";
			}
			
			for (int i = 0; i < back; i++)
			{
				toReturn += values[i] + " ";
			}
		}
		
		toReturn += "<--back";
		
		return toReturn;
	}
}
