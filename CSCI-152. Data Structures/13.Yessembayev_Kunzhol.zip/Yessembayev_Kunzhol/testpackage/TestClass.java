
package testpackage;
import csci152.adt.*;
import csci152.impl.*;


public class TestClass {
    public static void main(String[] args) throws Exception{
        Deque<Integer> hard = new LinkedListDeque<Integer>();
        
//        hard.popFromFront();
//        System.out.println(hard);
//        System.out.println(hard.getSize());
//        hard.popFromBack();
//        System.out.println(hard);
//        System.out.println(hard.getSize());
        
        for(int i=0; i<5; i++){
            hard.pushToFront(i);
        }
        System.out.println(hard);
        System.out.println(hard.getSize());
        
        for(int i=0; i<5; i++){
            hard.popFromFront();
        }
        System.out.println(hard);
        System.out.println(hard.getSize());
        
        for(int i=0; i<6; i++){
            hard.pushToFront(i);
        }
        System.out.println(hard);
        System.out.println(hard.getSize());
        
        for(int i=0; i<6; i++){
            hard.popFromBack();
        }
        System.out.println(hard);
        System.out.println(hard.getSize());
        
        for(int i=0; i<7; i++){
            hard.pushToBack(i);
        }
        System.out.println(hard);
        System.out.println(hard.getSize());
        
        for(int i=0; i<7; i++){
            hard.popFromBack();
        }
        System.out.println(hard);
        System.out.println(hard.getSize());
        
        for(int i=0; i<8; i++){
            hard.pushToBack(i);
        }
        System.out.println(hard);
        System.out.println(hard.getSize());
        
        for(int i=0; i<8; i++){
            hard.popFromFront();
        }
        System.out.println(hard);
        System.out.println(hard.getSize());
        
         for(int i=0; i<10; i++){
            hard.pushToFront(i);
            hard.pushToBack(i);
            
        }
        System.out.println(hard);
        System.out.println(hard.getSize());
        
        for(int i=0; i<8; i++){
            hard.popFromFront();
            hard.popFromBack();
            
        }
        System.out.println(hard);
        System.out.println(hard.getSize());
        
        hard.clear();
        System.out.println(hard);
        System.out.println(hard.getSize());
        
         for(int i=0; i<12; i++){
            hard.pushToFront(i);
            hard.pushToBack(i);
            
        }
        System.out.println(hard);
        System.out.println(hard.getSize());
    }
}
