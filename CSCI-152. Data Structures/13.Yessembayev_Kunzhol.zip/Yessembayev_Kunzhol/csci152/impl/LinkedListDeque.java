
package csci152.impl;

import csci152.adt.*;

public class LinkedListDeque<T> implements Deque<T> {
    
    private DoublyLinkedNode<T> front;
    private DoublyLinkedNode<T> back;
    int size;

    public LinkedListDeque(){
        front=null;
        back=null;
        size=0;
    }
    
    @Override
    public void pushToFront(T value) {
        DoublyLinkedNode<T> temp = new DoublyLinkedNode(value);
        
        if(size == 0){
            front = temp;
            back = temp;
        }
        else{
              front.setPrevious(temp);
              temp.setNext(front);
              front = temp;
        }   
        size++;
    }

    @Override
    public void pushToBack(T value) {
        DoublyLinkedNode<T> temp = new DoublyLinkedNode(value);
        
        if(size == 0){
            front = temp;
            back = temp;
        }
        else{
            back.setNext(temp);
            temp.setPrevious(back);
            back = temp;
        }   
        size++;
    }

    @Override
    public T popFromFront() throws Exception {
        if(size==0){
            throw new Exception("Queue is empty");
        }
        
        T value=front.getValue();
        if (front.getNext() != null)
        {
            front.getNext().setPrevious(null);
            front = front.getNext();
        }
        else
        {
            front = null;
            back = null;
        }
        
        size--;
            
            return value;
    }

    @Override
    public T popFromBack() throws Exception {
        if(size==0){
            throw new Exception("Queue is empty");
        }
        
        T value=back.getValue();
        if (back.getPrevious() != null)
        {
        back.getPrevious().setNext(null);
        back = back.getPrevious();
        }
        else{
            back=null;
            front = null;
        }
        size--;
            
            return value;
    }

    @Override
    public int getSize() {
        return size;
    }

    @Override
    public void clear() {
        front=null;
        back=null;
        size=0;
    }
    
    public String toString(){
        String toReturn = "";
        DoublyLinkedNode<T> clone = front;
        while(clone!=null){
            toReturn+=clone.toString() + " ";
            clone=clone.getNext();
        }

        return "front--> " + toReturn + "<--back";
    }
}
