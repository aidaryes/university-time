
package csci152.impl;

import csci152.adt.*;

public class LinkedListSortedQueue<T extends Comparable> implements SortedQueue<T> {

    private Node<T> front;
    private int size;
    
    @Override
    public void insert(T value) {
        Node<T> newNode = new Node(value);
        if(size==0){
            front=newNode;
        }
        else{
            if(value.compareTo(front.getValue())<0){
                newNode.setLink(front);
                front=newNode;
            }
            else{
                Node<T> temp = front;
                
                while (temp.getLink() != null && value.compareTo(temp.getLink().getValue()) > 0)
                {
                    temp = temp.getLink();
                }
                
                if (temp.getLink() != null)
                {
                    newNode.setLink(temp.getLink());
                    temp.setLink(newNode);
                }
                else
                {
                    temp.setLink(newNode);
                }
                
                
                
            }
        }
        
        size++;
    }

    @Override
    public T dequeue() throws Exception {
            if(size==0){
                throw new Exception("Queue is empty");
            }
        
        T value=front.getValue();
        front = front.getLink();
        size--;
            
            if(size==0){
                front=null;
            }
        return value;
    }

    @Override
    public int getSize() {
        return size;
    }

    @Override
    public void clear() {
        front=null;
        size=0;
    }
    
    public String toString(){
               String toReturn = "";
        Node<T> clone = front;
        while(clone!=null){
            toReturn+=clone.toString() + " ";
            clone=clone.getLink();
        }

        return "front--> " + toReturn + "<--back";
    }
    
    }
