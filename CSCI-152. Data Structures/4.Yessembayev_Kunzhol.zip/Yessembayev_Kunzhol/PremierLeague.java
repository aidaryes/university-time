
package football;

public class PremierLeague extends Football {
        
    public PremierLeague(String name, int budget){
        super(name, budget);
    }
    public void infrastructure(){
        System.out.println("Club has perfect fields and good infrastructure");
    }
        
    @Override
    public void decreaseBudget(int budget){
        System.out.println("You can not decrease the budget, because fans will be displeased and require your resignation");
    }
   
    @Override
    public void spendMoney (){
       super.decreaseBudget(100);
       System.out.println("You spend money to buy one special football player");
       }
        
    @Override
    public String toString(){
       return getName() + " is football club in PremierLeague " + "and has rest money about " + getMoney();
   }
}
