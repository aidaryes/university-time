
package football;

public class Football {

   private String name;
   private int budget;
   
   public Football(String name, int budget){
       this.name = name;
       this.budget = budget;
   }
    
   public void increaseBudget(int budget){
       this.budget += budget;
   }
   
   public void decreaseBudget(int budget){
       if(this.budget<0){
           System.out.println("You can not decrease the budget");
       }
       else{
       this.budget -= budget;
       }
   }
   
   public void spendMoney (){
       if(this.budget<100){
           System.out.println("You can not spend money for transfer");
       }
       else{
       this.budget -= 100;
       System.out.println("You spend money for the transfer");
       }
   }
   
   public void earnMoney (){
       this.budget +=1000;
   }
  
   public void buildStadion(){
       if(this.budget<1000){
           System.out.println("You can not build the stadion");
       }
       else{
       this.budget -= 1000;
       System.out.println("You start building the stadion");
       }
   }
   
   public String getName(){
       return this.name;
   }
   
   public int getMoney(){
       return this.budget;
   }
      
   public String toString(){
       return this.name + " football club " + "and rest money is " + this.budget;
   }
}
