
package football;

public class Working_space {
    
     public static void main(String[] args) {
        Football exeter = new Ligue1("Exeter", 100);
        System.out.println(exeter);
        Ligue1 exeter1 = (Ligue1) exeter;
        exeter1.budget();
        exeter.buildStadion();
        exeter.increaseBudget(100);
        exeter.earnMoney();
        
        Football leeds = new Championship("Leeds", 400);
        System.out.println(leeds);
        leeds.buildStadion();
        leeds.increaseBudget(500);
        leeds.earnMoney();
        Championship leeds1 = (Championship) leeds;
        leeds1.fans();
        
        Football liverpool = new PremierLeague("Liverpool", 2000);
        System.out.println(liverpool);
        liverpool.buildStadion();
        System.out.println("Your rest money "+liverpool.getMoney());
        liverpool.spendMoney();
        liverpool.decreaseBudget(100);
        
        
    }
}
