
package football;


public class Championship extends Football {
    
    public Championship(String name, int budget){
        super(name, budget);
        
    }
   public void fans(){
        System.out.println("Fans support this club from the whole world");
   }
   
    /**
     *
     * @param budget
     */
    @Override
    public void increaseBudget(int budget){
        super.increaseBudget(budget);
        System.out.println("You can increase the budget by "+getMoney());
    }
    
    @Override
    public void earnMoney(){
        System.out.println("Sponsors are in a bad mood and you can not earn money");
    }
    
    @Override
   public String toString(){
        return getName() + " is football club in Championship " + "and has rest money about " + getMoney();
   }
}
