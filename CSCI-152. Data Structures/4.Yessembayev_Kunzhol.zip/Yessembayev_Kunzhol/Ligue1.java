
package football;

public class Ligue1 extends Football {
    
    public Ligue1 (String name, int budget){
        super(name, budget);
    }
    
    public void budget(){
       System.out.println("Club is in bad financial condition");    
    }
    @Override
    public void increaseBudget(int budget){
       System.out.println("You can not increase the budget");
    }
    
    @Override
    public void earnMoney(){
        System.out.println("Due to bad financial condition, this club can not earn money");
    }
        
    @Override
    public String toString(){
       return getName() + " is football club in League 1 " + "and has rest money about " + getMoney();
    }
}
