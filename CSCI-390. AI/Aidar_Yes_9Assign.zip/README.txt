Actual data with 10000 run is located in output.csv file

However, in my computer, the process with all calculations took so long time (I have a poor processor)
So I decided to run it in a small dataset new.csv file, which is a small part of original output.csv file

Therefore, I, unfortunately, could not write my results in another file or do calculations 4! times

At least I did this task, and it works fine :)