First task: Babanov's theorem
Second task: random number of wall/pit/gold/monster
	and it returns what (w/p/g/m) is allocated in which cell
Third task: it returns where the wind or smell is allocated
	{0: {'wind': 1}, 1: {}, 2: {'wind': 1, 'smell': 0.5}}